This is the RESTFul Backend project which contains all the Web-Api controllers, EntityFramework .edmx classes.
