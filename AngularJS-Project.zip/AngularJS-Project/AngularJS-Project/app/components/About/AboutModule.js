﻿//Writing a seperate angular module for the About Us Module
(function () {
    angular.module('AboutModule', []);
})();
