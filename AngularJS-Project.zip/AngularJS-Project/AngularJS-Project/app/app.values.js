﻿(function () {

    angular
        .module('TemplateSellingApp')
        .value('values', {

        });

})();